document.addEventListener("DOMContentLoaded", function() {
    // Hard-coded exchange rates
    const exchangeRates = {
        "USD": {
            "CAD": 1.36, // Rate on 6th April,2024
            "USD": 1     // USD to USD rate (1:1)
        },
        "CAD": {
            "USD": 0.74, // Rate on 6th April, 2024
            "CAD": 1     // CAD to CAD rate (1:1)
        }
    };

    // Get select elements
    const fromSelect = document.querySelector('.from select');
    const toSelect = document.querySelector('.to select');

    // Add currency options to select elements
    for (let currency in exchangeRates) {
        const option1 = document.createElement('option');
        option1.value = currency;
        option1.textContent = currency;
        const option2 = option1.cloneNode(true);
        fromSelect.appendChild(option1);
        toSelect.appendChild(option2);
    }

    // Function to get exchange rate
    function getExchangeRate() {
        const fromCurrency = fromSelect.value;
        const toCurrency = toSelect.value;
        const amount = parseFloat(document.querySelector('.amount input').value);

        // Check for valid input
        if (isNaN(amount) || amount <= 0) {
            alert("Please enter a valid amount.");
            return;
        }

        // Check if exchange rate is available
        if (!(fromCurrency in exchangeRates) || !(toCurrency in exchangeRates[fromCurrency])) {
            alert("Error.");
            return;
        }

        // Get exchange rate
        const rate = exchangeRates[fromCurrency][toCurrency];

        // Calculate converted amount
        let convertedAmount;
        if (fromCurrency === toCurrency) {
            convertedAmount = amount; // Same currency, no conversion needed
        } else {
            convertedAmount = amount * rate;
        }

        // Display exchange rate and converted amount
        document.querySelector('.exchange-rate').textContent = `Exchange Rate: 1 ${fromCurrency} = ${rate} ${toCurrency}`;
        document.querySelector('.amount p').textContent = `Converted Amount (${toCurrency}):`;
        document.querySelector('.amount input').value = convertedAmount.toFixed(3);
    }

    // Event listener for button click
    document.querySelector('form button').addEventListener('click', function(event) {
        event.preventDefault();
        getExchangeRate();
    });

    // Event listener for exchange icon click (to swap currencies)
    document.querySelector('.icon').addEventListener('click', function() {
        const temp = fromSelect.value;
        fromSelect.value = toSelect.value;
        toSelect.value = temp;
        getExchangeRate(); // Recalculate exchange rate and converted amount when currencies are swapped
    });
});
